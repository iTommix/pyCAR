#!/usr/bin/python3
# -*- coding: utf-8 -*-
from PyQt4 import QtCore, QtGui, uic
import sys, platform, os, alsaaudio, importlib
import modules.functions as functions

from modules.py_mp3 import pymp3
from modules.py_iradio import pyradio
from modules.py_a2dp import pya2dp
from modules.py_phone import pyphone

path=os.path.dirname(os.path.abspath( __file__ ))
form_class = uic.loadUiType(path+"/sources/pycar.ui")[0]

settings = {
    "mute" : 0,
    "balance"           : 0,
    "currentVolume"     : 30,
    #"mainVolume"        : [30,30,30,30],
    "mainVolume"        : [30,30],
}

class pyCAR(QtGui.QMainWindow, form_class):

    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        self.settings=settings
        functions.init(self)
        self.volumeViewSetup()
        self.setVolume()
        self.player=None

        # add modules to pyCAR
        self.mp3_module=pymp3(self)
        vbox = QtGui.QVBoxLayout(self.mp3)
        vbox.addWidget(self.mp3_module.frame)
        
        self.radio_module=pyradio(self)
        vbox = QtGui.QVBoxLayout(self.radio)
        vbox.addWidget(self.radio_module.frame)
        
        self.a2dp_module=pya2dp(self)
        vbox = QtGui.QVBoxLayout(self.a2dp)
        vbox.addWidget(self.a2dp_module.frame)
        
        self.phone_module=pyphone(self)
        vbox = QtGui.QVBoxLayout(self.phone)
        vbox.addWidget(self.phone_module.frame)



    def main_button(self, value):
        deck=int(value)
        if deck==2: # Radio
            self.muteAll("radio")
            self.radio_module.setChanel(self.radio_module.settings["currentStation"])
        
        self.mainFrame.setCurrentIndex(deck)
        self.mp3_module.frame.setGeometry(QtCore.QRect(0, 0, 2100, 480))
        self.radio_module.frame.setGeometry(QtCore.QRect(0, 0, 1400, 480))
        self.a2dp_module.frame.setGeometry(QtCore.QRect(0, 0, 1400, 480))
        self.phone_module.frame.setGeometry(QtCore.QRect(0, 0, 2800, 480))

        
    def muteAll(self, sender):
        print(sender)
        modules=["mp3_module", "radio_module", "a2dp_module"]
        for module in modules:
            if sender+"_module" != module:
                player=getattr(self, module)
                print(module+" => "+str(player.playing()))
                if player.playing():
                    self.player=player
                    self.player.mute()
                    break

    def play(self):
        print(self.player)
        if self.player!=None:
            self.player.play()
            self.player=None
        
        
    def home_button(self):
        if self.mainFrame.currentIndex()==0:
            functions.homebutton()       
        else:
            self.mainFrame.setCurrentIndex(0)


########################################################################
##
## Section Volume-Functions
##
########################################################################
        
    def mute(self):
        button=self.findChild(QtGui.QToolButton, "btn_Mute")
        mixer = alsaaudio.Mixer()
        if self.settings["mute"]==0:
            self.settings["mute"]=1
            mixer.setmute(1)
            button.setStyleSheet("background-image: url(./images/mute_off.png);background-repeat: none; border: 0px;")
        else:
            mixer.setmute(0)
            self.settings["mute"]=0
            button.setStyleSheet("background-image: url(./images/mute_on.png);background-repeat: none; border: 0px;")
    
    def volume(self, mode):
        self.volumeView.show()
        self.volumeViewTimer.start(2000)
        if mode=="up":
            if settings["currentVolume"]<100:
                settings["currentVolume"]+=5
                self.volumeSlider.setValue(settings["currentVolume"])
                self.setBalance()
        else:
            if settings["currentVolume"]>0:
                settings["currentVolume"]-=5
                self.volumeSlider.setValue(settings["currentVolume"])
                self.setBalance()
                
    def setBalance(self):
        b=settings["balance"]
        if b>0:
            f=100-b
            #self.lblBalanceLeft.setText(str(f)+"%")
            settings["mainVolume"][0]=int((settings["currentVolume"]/100)*f)
            settings["mainVolume"][2]=int((settings["currentVolume"]/100)*f)
        elif b<0:
            f=100-abs(b)
            #self.lblBalanceRight.setText(str(f)+"%")
            settings["mainVolume"][1]=int((settings["currentVolume"]/100)*f)
            settings["mainVolume"][3]=int((settings["currentVolume"]/100)*f)
        else:
            #self.lblBalanceLeft.setText("100%")
            #self.lblBalanceRight.setText("100%")
            print("Balance is equal, so volume is "+str(settings["currentVolume"]))
            c=0
            for v in settings["mainVolume"]:
                settings["mainVolume"][c]=settings["currentVolume"]
                c+=1
        self.setVolume()
        
    def setVolume(self):
        mixer = alsaaudio.Mixer()
        c=0
        s=""
        for v in settings["mainVolume"]:
            print(str(c)+" = "+str(v))
            mixer.setvolume(int(v), c)
            s+=str(v)+","
            c+=1
        self.settings["mainVolume"]= s[:-1].split(",")
        
    def hideVolumeView(self):
        self.volumeView.hide()
        self.volumeViewTimer.stop()


    def volumeViewSetup(self):
        self.volumeView = QtGui.QWidget(self)
        self.volumeView.setGeometry(QtCore.QRect(290, 120, 320, 180))
        self.volumeView.setObjectName("volumeView")
        self.volumeView.setStyleSheet("background-image: url(./images/volumeViewBG.png); border-radius: 10px;")
        self.volumeSlider = QtGui.QProgressBar(self.volumeView)
        self.volumeSlider.setGeometry(QtCore.QRect(10, 80, 300, 22))
        self.volumeSlider.setMaximum(100)
        self.volumeSlider.setValue(30)
        self.volumeSlider.setStyleSheet("border-width: 0px; background: transparent;color: #edc87e; font-weight: bold; text-align: center; background-color: #aaaaaa")
        self.volumeSlider.setOrientation(QtCore.Qt.Horizontal)
        self.volumeSlider.setObjectName("volumeSlider")
        self.volumeView.hide()
        self.volumeViewTimer = QtCore.QTimer()
        self.volumeViewTimer.timeout.connect(self.hideVolumeView)


def main():
    app = QtGui.QApplication(sys.argv)
    form = pyCAR()

    if platform.system()=="Darwin":
        form.show()
    else:
        if len(sys.argv)>1:
            if sys.argv[1]=="nfs":
                form.show()
        else:
            form.showFullScreen()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()