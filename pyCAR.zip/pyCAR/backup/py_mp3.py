from PyQt4 import QtCore, QtGui, uic
from PyQt4.QtGui import QIcon
import mplayer, sys, os, json, time
from mutagen import File
from mutagen.id3 import ID3
from mutagen.mp3 import MP3
from mutagen.mp4 import MP4
from PIL import Image
from PIL import ImageFilter
from subprocess import call

path=os.path.dirname(os.path.abspath( __file__ )).rsplit('/', 1)
form_class = uic.loadUiType(path[0]+"/sources/pymp3.ui")[0]

settings = {
    "currentAlbum"      : "",
    "currentSong"       : "",
    "shuffle"           : 0,
    "repeat"            : 0,
    "pause"             : 0
}

music={}

mp3player = mplayer.Player()

class pymp3(QtGui.QMainWindow, form_class):

    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.parent=parent
        self.setupUi(self)
        self.settings=settings
        # setup timers
        self.playTimer = QtCore.QTimer()
        self.playTimer.timeout.connect(lambda: self.setSlider())
        self.settings["pause"]=1
        # setup buttons
        self.btn_Select.clicked.connect(lambda: self.startSlide("left"))
        self.btn_Back.clicked.connect(lambda: self.startSlide("right"))
        self.slideback.clicked.connect(lambda: self.startSlide("right"))
        self.btn_Backward.clicked.connect(lambda: self.backward())
        self.btn_Forward.clicked.connect(lambda: self.forward())
        self.btn_Like.clicked.connect(lambda: self.like())
        self.btn_Repeat.clicked.connect(lambda: self.repeat())
        self.btn_Shuffle.clicked.connect(lambda: self.shuffle())
        self.btn_Play.clicked.connect(lambda: self.play())
        self.btn_Interprets.clicked.connect(lambda: self.selectList("interprets"))
        self.btn_Album.clicked.connect(lambda: self.selectList("alben"))
        self.musicSlider.sliderReleased.connect(self.setPosition)
        self.albumList.itemClicked.connect(lambda: self.getSongs())
        self.musicList.itemClicked.connect(lambda: self.newSong())
        self.musicList.verticalScrollBar().setStyleSheet("QScrollBar:vertical {width:50px}");
        self.albumList.verticalScrollBar().setStyleSheet("QScrollBar:vertical {width:50px}");
        # evaluate music
        self.getMusic()
     

    def mute(self):
        if self.settings["pause"]==0:
            self.play()
            
    def playing(self):
        if self.settings["pause"]==1:
            return 0
        return 1
    
    def pause(self):
        pass
    
    def stop(self):
        pass
    
    def play(self):
        if self.settings["pause"]==0:
            self.settings["pause"]=1
            self.btn_Play.setStyleSheet("background-image: url("+path[0]+"/images/play.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
            mp3player.pause()
            self.playTimer.stop()
        else:
            self.parent.muteAll("mp3")
            self.settings["pause"]=0
            self.btn_Play.setStyleSheet("background-image: url("+path[0]+"/images/pause.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
            mp3player.pause()
            self.pullInfo()
            self.playTimer.start(1000)
            
    def pullInfo(self):
        self.parent.lbl_Artist.setText(self.lbl_Artist.text())
        self.parent.lbl_Title.setText(self.lbl_Title.text())

    def newSong(self):
        self.parent.muteAll("mp3")
        self.songChanged()
        self.frame.setGeometry(QtCore.QRect(0, 0, 2100, 480))

    def songChanged(self):
        song=self.music[self.settings["currentAlbum"]][self.musicList.currentRow()]
        self.lbl_Artist.setText(song["artist"])
        self.lbl_Album.setText(song["album"])
        self.lbl_Title.setText(song["title"])
        self.settings["currentSong"]=song["title"]
        self.player.setStyleSheet("background-image: url("+ self.changeBackground(song["path"], song["title"]) +");")
        mp3player.loadfile(song["path"]);
        self.lbl_Time.setText(self.getSongLength(mp3player.length))
        self.musicSlider.setMaximum(int(mp3player.length))
        self.musicSlider.setValue(0)
        self.btn_Play.setStyleSheet("background-image: url("+path[0]+"/images/pause.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
        self.settings["pause"]=0;
        self.playTimer.start(1000)
        
        
    def setSlider(self):
        self.pullInfo()
        self.musicSlider.setValue(self.musicSlider.value()+1)
        if mp3player.filename is None:
            self.settings["position"]=0
            if self.settings["shuffle"]==1:
                s=self.getRandomSong()
                while self.music[self.albumList.currentItem().text()][str(s)]["played"]==1:
                    s=self.getRandomSong()
                #self.songChanged(self.music[self.albumList.currentItem().text()][str(s)])
                
            elif self.settings["repeat"]==0:
                self.musicList.setCurrentRow(self.musicList.currentRow()+1)
                self.songChanged()
            else:
                if self.settings["repeat"]==1:
                    self.settings["repeat"]=0
                    self.btn_Repeat.setStyleSheet("background-image: url("+path[0]+"/images/repeat.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
                self.songChanged()
        else:
            self.lbl_Time.setText(self.getSongLength(mp3player.length-mp3player.time_pos))
            self.settings["position"]=mp3player.time_pos
            
    def backward(self):
        if self.musicList.currentRow()>0:
            if self.musicSlider.value()<5:
                self.musicList.setCurrentRow(self.musicList.currentRow()-1)
            self.songChanged()
    
    def forward(self):
        if self.musicList.currentRow()<self.musicList.count()-1:
            self.musicList.setCurrentRow(self.musicList.currentRow()+1)
            self.songChanged()
    
    def like(self):
        song=self.music[settings["currentAlbum"]][str(self.musicList.currentRow())]
        if self.lbl_Title.text() != "":
            like = self.findLikeFile(song)
            txt=self.buildLikeFile(song)
            if like:
                os.remove("/media/pi/pyCar/Music/.likes/"+txt.replace(" ","_"))
                self.btn_Like.setStyleSheet("background-image: url("+path[0]+"/images/like.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
            else:
                with open("/media/pi/pyCar/Music/.likes/"+txt.replace(" ","_"), 'w') as outfile:
                    json.dump(song, outfile, indent=4, sort_keys=False, separators=(',', ':'))
                self.btn_Like.setStyleSheet("background-image: url("+path[0]+"/images/liked.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")

    
    def repeat(self):
        if self.settings["shuffle"]==1:
            self.shuffle()
        if self.lbl_Title.text() != "":
            if self.settings["repeat"]==0:
                self.settings["repeat"]=1
                self.btn_Repeat.setStyleSheet("background-image: url("+path[0]+"/images/repeat1.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
            elif self.settings["repeat"]==1:
                self.settings["repeat"]=2
                self.btn_Repeat.setStyleSheet("background-image: url("+path[0]+"/images/repeat.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 2px solid #e42659;background-position: center")
            else:
                self.settings["repeat"]=0
                self.btn_Repeat.setStyleSheet("background-image: url("+path[0]+"/images/repeat.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")

    
    def shuffle(self):
        if self.settings["repeat"]>0:
            self.settings["repeat"]=2
            self.repeat()
        if self.lbl_Title.text() != "":
            if self.settings["shuffle"]==0:
                self.settings["shuffle"]=1
                self.btn_Shuffle.setStyleSheet("background-image: url("+path[0]+"/images/shuffle.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 2px solid #e42659;background-position: center")
            else:
                self.settings["shuffle"]=0
                self.btn_Shuffle.setStyleSheet("background-image: url("+path[0]+"/images/shuffle.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border:0px;background-position: center")

    
    def setPosition(self):
        if mp3player.time_pos>0:
            mp3player.time_pos=self.musicSlider.value()
    
    def getSongLength(self, value):
        m, s = divmod(value, 60)
        #h, m = divmod(m, 60)
        #"%d:%02d:%02d" % (h, m, s)
        return "%02d:%02d" % (m, s)
    
    
########################################################################
##
## Image functions
##
########################################################################

    def extract_path(self, path, sep=os.sep):
        path, filename = os.path.split(os.path.abspath(path))
        bottom, rest = path[1:].split(sep, 1)
        bottom = sep + bottom
        middle, top = os.path.split(rest)
        return bottom+"/"+middle+"/"+top+"/"
    
     
    def getSongCover(self, filename, name):
        path=self.extract_path(filename)
        if not os.path.exists(path+name):
            call('ffmpeg -loglevel panic -i "'+filename+'" -an -vcodec copy "'+path+name+'"', shell=True)
            if not os.path.exists(path+name):
                return "./images/nocover.png"
        return path+name
            
    def getAlbumCover(self, f, name):
        if os.path.exists(name): os.remove(name)
        call("ffmpeg -loglevel panic -i '"+f+"' -an -vcodec copy "+name, shell=True)

    def changeBackground(self, f, title):
        try:
            self.getAlbumCover(f, "bg.jpg")
            source = Image.open("bg.jpg")
            source=source.filter(ImageFilter.GaussianBlur(4))
            if source.width<700:
                width=700
                height=int(width * (source.height / source.width))
                source = source.resize((width, height), Image.ANTIALIAS)
                top = int((height - 480)/2)
                bottom = int(height-top)
                box=[0,top,700,bottom]
                source=source.crop(box)
            elif source.height<480:
                pass
            else:
                left = int((source.width - 700)/2)
                right = int(source.width-left)
                top = int((source.height - 480)/2)
                bottom = int(source.height-top)
                box=[left,top,right,bottom]
                source=source.crop(box)
            
            ### Bild dunkler machen ###
            im = source.split()
            R, G, B = 0, 1, 2
            constant = 1.5 # constant by which each pixel is divided
            Red = im[R].point(lambda i: i/constant)
            Green = im[G].point(lambda i: i/constant)
            Blue = im[B].point(lambda i: i/constant)
            source = Image.merge(source.mode, (Red, Green, Blue))
            
            source.save("background.jpg")
            image="background.jpg"
        except:
            print("Unexpected error:", sys.exc_info()[0])
            image=path[0]+"/skins/alternate.png"        
        return image



########################################################################
##
## Slide functions
##
########################################################################

    def startSlide(self, direction):
        if direction=="left":
            self.slideEnd=self.frame.x()-700
        else:
            self.slideEnd=self.frame.x()+700       
        self.slideTimer = QtCore.QTimer()
        self.slideTimer.timeout.connect(lambda: self.slideFrame(direction))
        self.slideTimer.start(10)
               
    def slideFrame(self, direction):
        if direction=="left":
            x=self.frame.x()-25
        else:
            x=self.frame.x()+25
        self.frame.setGeometry(QtCore.QRect(x, 0, 2100, 480))
        if x==self.slideEnd:
            self.slideTimer.stop()

########################################################################
##
## File related functions
##
########################################################################

    def get_filepaths(self, directory, ftype):
        """
        This function will generate the file names in a directory 
        tree by walking the tree either top-down or bottom-up. For each 
        directory in the tree rooted at directory top (including top itself), 
        it yields a 3-tuple (dirpath, dirnames, filenames).
        """
        file_paths = []  # List which will store all of the full filepaths.
    
        # Walk the tree.
        for root, directories, files in os.walk(directory):
            if ftype=="d":
                for directory in directories:
                    file_paths.append(directory)
            else:
                for filename in files:
                    # Join the two strings in order to form the full filepath.
                    filepath = os.path.join(root, filename)
                    file_paths.append(filepath)  # Add it to the list.
    
        return file_paths  # Self-explanatory.
    
    def getSongs(self):
        if self.albumList.currentRow()>-1:
            sel=-1
            z=0
            path=os.path.realpath(__file__).rsplit('/', 2)
            call("rm "+ path[0] +"/cover*", shell=True)
            album=self.albumList.currentItem().text()
            self.settings["currentAlbum"]=album
            self.lbl_currentAlbum.setText(album);
            self.musicList.clear()
            self.musicList.clearSelection()

            for song in sorted(self.music[album]):
                itm = QtGui.QListWidgetItem(self.music[album][song]["title"]);
                if self.settings["currentSong"]==self.music[album][song]["title"]:
                    sel=z
                file = File(self.music[album][song]["path"]) # mutagen can automatically detect format and type of tags
                tstamp=str(time.time())
                try:
                    artwork = file.tags['APIC:'].data # access APIC frame and grab the image
                    with open('cover'+tstamp+'.jpg', 'wb') as img:
                        img.write(artwork) # write artwork to new image
                        image="cover"+tstamp+".jpg"
                except:
                    image=path[0]+"/images/nocover.png"       
                itm.setIcon(QIcon(image));
                self.musicList.addItem(itm);
                z+=1
            if sel>-1:
                self.musicList.setCurrentRow(sel)
            self.startSlide("left")
            
    def selectList(self, list):
        self.albumList.clear()
        self.albumList.clearSelection()
        if list=="alben":
            self.music=self.alben
            image="folder"
            itm = QtGui.QListWidgetItem("Favoriten");
            itm.setIcon(QIcon(r""+path[0]+"/images/likes.png"));
            self.albumList.addItem(itm);
        else:
            self.music=self.interprets
            image="interprets"
        for item in sorted(self.music):
            if item!="Favoriten":
                itm = QtGui.QListWidgetItem(item);
                itm.setIcon(QIcon(r""+path[0]+"/images/"+image+".png"));
                self.albumList.addItem(itm);

    
    def getFavorites(self):
        full_file_paths = self.get_filepaths("/media/pi/pyCar/Music/.likes", "f")
        favorites={}
        z=0
        for f in full_file_paths:
            with open(f) as infile:    
                fav=json.load(infile)
                favorites[z]={}
                favorites[z]=fav
                z+=1
        for index in sorted(favorites):
            self.alben["Favoriten"][index]=favorites[index]

        
    def getInterprets(self):
        interprets={}
        for album in sorted(self.alben):
            for index in sorted(self.alben[album]):
                song=self.alben[album][index]
                try:
                    interprets[self.alben[album][index]["artist"]][index]=song
                except:
                    interprets[self.alben[album][index]["artist"]]={}
        
        self.interprets=interprets         
          
        
    def getMusic(self):
        full_file_paths = self.get_filepaths("/media/pi/pyCar/Music", "d")
        for f in full_file_paths:
            if not f.startswith("."):
                music[f]={}
                i=0;
                full_mp3_path = self.get_filepaths("/media/pi/pyCar/Music/"+f, "s")
                for mp3 in full_mp3_path:
                    if mp3.lower().endswith(".mp3") or mp3.lower().endswith(".m4a"):
                        m = File(mp3, easy=True)
                        music[f][i] = {}
                        
                        for tag in ('title', 'artist', 'album'):
                            test=str(m[tag][0])
                            music[f][i][tag] = str(m[tag][0])
                            #print(tag + " => "+ test)
                        music[f][i]["path"]=mp3
                        music[f][i]["played"]=0
                        i=i+1                        
                            
        self.albumList.clear()
        self.albumList.clearSelection()
        
        itm = QtGui.QListWidgetItem("Favoriten");
        itm.setIcon(QIcon(r""+path[0]+"/images/likes.png"));
        self.albumList.addItem(itm);
        
        
        
        sel=-1
        z=1
        for album in sorted(music):
            itm = QtGui.QListWidgetItem(album);
            itm.setIcon(QIcon(r""+path[0]+"/images/folder.png"));
            self.albumList.addItem(itm);
            if album==self.settings["currentAlbum"]:
                sel=z
                self.lblAlbum.setText(album)
            z+=1
        if sel>-1:
            print(sel)
            self.albumList.setCurrentRow(sel)
        self.alben=music
        self.alben["Favoriten"]={}
        self.getFavorites()
        self.getInterprets()
        self.music=self.alben
        
        
        
    def findLikeFile(self, song):
        like=self.buildLikeFile(song)
        if os.path.exists("/media/pi/pyCar/Music/.likes/"+like.replace(" ", "_")):
            return 1
        else:
            return 0
        
    def buildLikeFile(self, song):
        parts = song["path"].split("/")
        song=parts[len(parts)-1].split(".")
        like = song[0] + ".txt"
        return like

    def liked(self, song):
        like=self.buildLikeFile(song)
        if os.path.exists("/media/pi/pyCar/Music/.likes/"+like):
            self.btn_Like.setStyleSheet("background-image: url("+path[0]+"/images/liked.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
        else:
            self.btn_Like.setStyleSheet("background-image: url("+path[0]+"/images/like.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")




















    
    
def main():
    app = QtGui.QApplication(sys.argv)
    form = pymp3()
    form.show()
    sys.exit(app.exec_())
    
if __name__ == "__main__":
    main()