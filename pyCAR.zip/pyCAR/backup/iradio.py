import mplayer, sys, os, json, time

player = mplayer.Player()


player.loadfile('http://charthits-high.rautemusik.fm')
player.pause()