from subprocess import call
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from functools import partial
from xml.dom import minidom
import subprocess
import os, sys, time


def init(pyCAR):
    #startNavit(pyCAR)    
    setButtons(pyCAR)    

def startModule(pyCAR, modul):
    path=os.path.realpath(__file__).rsplit('/', 1)
    call("cd "+ path[0] +" && python3 py_"+modul+".py &", shell=True)
    cmd="xwininfo -name '"+ modul +"' | sed -e 's/^ *//' | grep -E 'Window id' | awk '{ print $4 }'"
    wid='';
    while wid=='' :
        proc = subprocess.check_output(cmd, shell=True)
        wid=proc.decode("utf-8").replace("\n","");
    
    time.sleep(0.5)
    page=getattr(pyCAR, modul)
    window = QtGui.QX11EmbedContainer(page)
    window.resize(700, 480)
    window.embedClient(int(wid, 16))
    print(window)

def startNavit(pyCAR):
    try:
        os.remove("/home/pyCAR/lastspeak.txt")
    except:
        pass
    process = subprocess.Popen(['navit', '-c', '/usr/local/share/navit/navit.xml'],stdout=subprocess.PIPE, shell=True)
    pid = str(process.pid)
    time.sleep(2)
    cmd='xwininfo -name \'Navit\' | sed -e \'s/^ *//\' | grep -E "Window id" | awk \'{ print $4 }\''
    wid='';
    while wid=="" :
        proc = subprocess.check_output(cmd, shell=True)
        wid=proc.decode("utf-8").replace("\n","");

    time.sleep(0.5)
    page=getattr(pyCAR, "navigation")
    window = QtGui.QX11EmbedContainer(page)
    window.resize(700, 480)
    window.embedClient(int(wid, 16))
    
def setButtons(pyCAR):
    path=os.path.realpath(__file__).rsplit('/', 2)
    dom = minidom.parse(path[0]+'/sources/main.xml')
    root = dom.documentElement
    font = QtGui.QFont()
    font.setPointSize(36)
    font.setBold(True)
    font.setWeight(75)
    if root.childNodes:
        for node in root.childNodes:
            #print (node.attributes['skin'].value)
            if node.nodeType == node.ELEMENT_NODE:
                print (node.tagName,"has value:",  node.attributes['skin'].value, "and is child of:", node.parentNode.tagName)
                itemlist = node.getElementsByTagName('item')
                for s in itemlist:
                    getattr(pyCAR, node.tagName).setStyleSheet("background-image: url(./skins/"+ node.attributes['skin'].value +")")
                    button = QtGui.QToolButton(getattr(pyCAR, node.tagName))
                    button.setFont(font)
                    button.setObjectName("btn_"+s.attributes['name'].value)
                    button.setGeometry(QtCore.QRect(int(s.attributes['x'].value), int(s.attributes['y'].value), int(s.attributes['w'].value), int(s.attributes['h'].value)))
                    css="background: transparent; border: 0px;"
                    if s.attributes['image'].value:
                        if s.attributes['class'].value=="button":
                            css="background-image: url(./images/"+ s.attributes['image'].value +");background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center"
                        else:
                            css="background-image: url(./images/"+ s.attributes['image'].value +");background-repeat: none; border: 0px"
                    try:
                        if s.attributes['text'].value:
                            css="background-image: url(./images/clear.gif);background-color: #eeeeee; border-radius: 5px;"
                            button.setText(s.attributes['text'].value)
                    except:
                        pass
                    button.setStyleSheet(css)
                    if s.attributes['value'].value:
                        button.clicked.connect(partial(getattr(pyCAR, s.attributes['eval'].value), s.attributes['value'].value))
                    else:
                        button.clicked.connect(partial(getattr(pyCAR, s.attributes['eval'].value)))

def getSongLength(value):
    m, s = divmod(value, 60)
    #h, m = divmod(m, 60)
    #"%d:%02d:%02d" % (h, m, s)
    return "%02d:%02d" % (m, s)
                      
def homebutton():
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Question)
    msg.setText("Was möchtest Du tun:")
    #msg.setInformativeText("Abort = Reboot")
    msg.setWindowTitle("pyCAR beenden")
    msg.addButton(QtGui.QPushButton('Beenden'), QtGui.QMessageBox.YesRole)
    msg.addButton(QtGui.QPushButton('Abbrechen'), QtGui.QMessageBox.NoRole)
    msg.addButton(QtGui.QPushButton('Reboot'), QtGui.QMessageBox.RejectRole)
    msg.addButton(QtGui.QPushButton('Shutdown'), QtGui.QMessageBox.ActionRole)
    retval = msg.exec_()
    print ("value of pressed message box button:", retval)
    if retval==0:
        call("sudo killall python3 && sudo killall navit &", shell=True)
        exit()
    elif retval==2:
        reboot()
    elif retval==3:
        shutdown()
        
def reboot():
    call("sudo reboot", shell=True)
    
def shutdown():
    call("sudo shutdown -h now", shell=True)