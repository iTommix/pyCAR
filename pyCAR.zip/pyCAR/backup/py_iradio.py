from PyQt4 import QtCore, QtGui, uic
from PyQt4.QtGui import QIcon
import mplayer, sys, os, json, time
from xml.dom import minidom

path=os.path.dirname(os.path.abspath( __file__ )).rsplit('/', 1)
form_class = uic.loadUiType(path[0]+"/sources/pyiradio.ui")[0]

settings = {
    "stations" :{
    },
    "currentStation"    : 1,
    "pause"             : 0
}

player = mplayer.Player()

class pyradio(QtGui.QMainWindow, form_class):

    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.parent=parent
        self.setupUi(self)
        self.stationList.itemClicked.connect(lambda: self.setChanel(self.stationList.currentRow()+1))
        self.settings=settings
        self.readChannels()
        
        
    def mute(self):
        if self.settings["pause"]==0:
            self.play()
            
    def playing(self):
        if self.settings["pause"]==1:
            return 0
        return 1
    
    def pause(self):
        pass
    
    def stop(self):
        pass
    
    def play(self):
        if self.settings["pause"]==0:
            self.settings["pause"]=1
            player.pause()
        else:
            self.parent.muteAll("radio")
            self.settings["pause"]=0
            self.setChanel(self.stationList.currentRow()+1)
            
            
    def pullInfo(self):
        self.parent.lbl_Artist.setText("")
        self.parent.lbl_Title.setText(self.lbl_Text.text())
        
    def setChanel(self, item):
        station=self.settings["stations"][item]
        self.lbl_Text.setText(station["name"])
        #if self.settings["currentStation"]!=item:
        player.loadfile(station["url"])
        self.settings["currentStation"]=item
        self.pullInfo()
        if self.settings["pause"]==1:
            self.settings["pause"]=0
            player.pause()
            
    
    def readChannels(self):
        i=1
        self.stationList.clear()
        self.stationList.clearSelection()
        path=os.path.realpath(__file__).rsplit('/', 2)
        dom = minidom.parse(path[0]+'/sources/radio.xml')
        items = dom.getElementsByTagName('item')
        for item in items:
            self.settings["stations"][i]={}
            self.settings["stations"][i]["name"]=item.attributes["name"].value
            self.settings["stations"][i]["url"]=item.attributes["url"].value
            itm = QtGui.QListWidgetItem(item.attributes["name"].value);
            image=path[0]+'/images/radio.png'
            if item.attributes["image"].value:
                image=item.attributes["image"].value
            itm.setIcon(QIcon(image));
            self.stationList.addItem(itm);
            i=i+1
