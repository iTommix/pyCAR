from PyQt4 import QtCore, QtGui, uic
from PyQt4.QtGui import QIcon
import sys, os, json, time, dbus
import modules.phone as phone, modules.functions as functions
from xml.dom import minidom


path=os.path.dirname(os.path.abspath( __file__ )).rsplit('/', 1)
form_class = uic.loadUiType(path[0]+"/sources/pya2dp.ui")[0]

settings = {
    "shuffle":0,
    "repeat":0,
    "a2dpPath":"/Filesystem",
    "pause":1
}


class pya2dp(QtGui.QMainWindow, form_class):

    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.parent=parent
        self.settings=settings
        self.setupUi(self)
        
        self.btn_Select.clicked.connect(lambda: self.startSlide("left"))
        self.slideback.clicked.connect(lambda: self.startSlide("right"))
        self.musicList.itemClicked.connect(self.select)
        self.musicList.verticalScrollBar().setStyleSheet("QScrollBar:vertical {width:50px}")
        self.btn_Repeat.clicked.connect(lambda: self.setProperties("repeat"))
        self.btn_Shuffle.clicked.connect(lambda: self.setProperties("shuffle"))
        self.btn_Forward.clicked.connect(lambda: self.function('Next'))
        self.btn_Backward.clicked.connect(lambda: self.function('Previous'))
        self.btn_Seekforward.clicked.connect(lambda: self.function('FastForward'))
        self.btn_Seekbackward.clicked.connect(lambda: self.function('Rewind'))
        self.btn_Play.clicked.connect(lambda: self.play())
        
        self.statusTimer = QtCore.QTimer()
        self.statusTimer.timeout.connect(self.status)
        self.statusTimer.start(500)
        
        self.a2dpPlayer='player0'
        self.setPlayer()
        self.browser()
        
        
    
    
    def pullInfo(self):
        self.parent.lbl_Artist.setText(self.lbl_Artist.text())
        self.parent.lbl_Title.setText(self.lbl_Title.text())
    
        
    def mute(self):
        if self.settings["pause"]==0:
            self.play()
            
    def pause(self):
        pass
    
    def stop(self):
        pass
            
    def play(self):
        device=phone.getConnectedDevice()
        if (device):
            self.parent.muteAll("a2dp")
            bus = dbus.SystemBus()
            props = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.freedesktop.DBus.Properties')
            status=dbus.String(props.Get('org.bluez.MediaPlayer1', "Status"))
            if status=="playing":
                self.function("Pause")
            else:
                self.function("Play")

    def playing(self):
        device=phone.getConnectedDevice()
        if device!=False:
            try:
                bus = dbus.SystemBus()
                props = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.freedesktop.DBus.Properties')
                status=dbus.String(props.Get('org.bluez.MediaPlayer1', "Status"))
                if status=="playing":
                    return 1
                else:
                    return 0
            except:
                pass
        else:
            return 0
                
    
    def function(self, function):
        device=phone.getConnectedDevice()
        if(device):
            bus = dbus.SystemBus()
            player = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.bluez.MediaPlayer1')
            if function=='Play':
                # Mute everything else:
                #self.stopMusic()
                player.Play()
            if function=="Pause":
                player.Pause()

            if function=='Next':
                player.Next()
            elif function=='Previous':
                player.Previous()
            elif function=='FastForward':
                player.FastForward()
                self.btn_Play.setStyleSheet("background-image: url(./images/play.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
            elif function=='Rewind':
                player.Rewind()
                self.btn_Play.setStyleSheet("background-image: url(./images/play.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
              
        
    def status(self):
        device=phone.getConnectedDevice()
        if device!=False:
            self.setPlayer()
            self.frame.setEnabled(1)
            self.lbl_Phone.setText(phone.getConnectedName(device))
            try:
                bus = dbus.SystemBus()
                props = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.freedesktop.DBus.Properties')
                status=dbus.String(props.Get('org.bluez.MediaPlayer1', "Status"))
                if status=="playing":
                    #
                    if self.settings["pause"]==1:
                        self.settings["pause"]=0
                        self.parent.muteAll("a2dp")
                        self.parent.main_button(5)
                    ## TODO: Zeit des aktuellen lieds
                    #if self.mainFrame.currentIndex!=8 and self.settings["system"]["player"]!="a2dp": self.mainFrame.setCurrentIndex(8)
                    #if self.settings["system"]["player"]!="a2dp": self.stopMusic()
                    #self.saveSettings("system","player", "a2dp")
                    #self.btnPausePlay.setStyleSheet("background-image: url(./images/play.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")                
                    self.btn_Play.setStyleSheet("background-image: url(./images/pause.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
                    playing = dbus.Dictionary(props.Get('org.bluez.MediaPlayer1', "Track"))
                    position=dbus.String(props.Get('org.bluez.MediaPlayer1', "Position"))
                    self.lbl_Time.setText(functions.getSongLength((playing["Duration"]-int(position))/1000))
                    self.musicSlider.setMaximum(playing["Duration"]/1000)
                    self.musicSlider.setValue(int(position)/1000)
                    self.lbl_Artist.setText(playing["Artist"])
                    self.lbl_Title.setText(playing["Title"])
                    self.lbl_Album.setText(playing["Album"])
                    self.pullInfo()
                elif status=="paused":
                    self.settings["pause"]=1
                    #self.lbl_Time.setText("00:00")
                    #self.musicSlider.setValue(0)
                    self.btn_Play.setStyleSheet("background-image: url(./images/play.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center") 
            except:
                pass
        else:
            self.lbl_Phone.setText("Nicht verbunden")
            self.frame.setEnabled(0)

    def setProperties(self, prop):
        device=phone.getConnectedDevice()
        bus = dbus.SystemBus()
        props = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.freedesktop.DBus.Properties')
        if prop=="repeat":
            #off, singletrack, alltracks
            if self.settings["repeat"]==0:
                self.settings["repeat"]=1
                self.btn_Repeat.setStyleSheet("background-image: url(./images/repeat1.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
                value="singletrack"
            elif self.settings["repeat"]==1:
                self.settings["repeat"]=2
                self.btn_Repeat.setStyleSheet("background-image: url(./images/repeat.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 2px solid #e42659;background-position: center")
                value="alltracks"
            else:
                self.settings["repeat"]=0
                self.btn_Repeat.setStyleSheet("background-image: url(./images/repeat.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 0px;background-position: center")
                value="off"
            props.Set('org.bluez.MediaPlayer1', "Repeat", value)
        if prop=="shuffle":
            #off, alltracks
            if self.settings["shuffle"]==0:
                self.settings["shuffle"]=1
                self.btn_Shuffle.setStyleSheet("background-image: url(./images/shuffle.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border: 2px solid #e42659;background-position: center")
                value="alltracks"
            else:
                self.settings["shuffle"]=0
                self.btn_Shuffle.setStyleSheet("background-image: url(./images/shuffle.png);background-repeat: none; background-color: #eeeeee; border-radius: 5px; border:0px;background-position: center")
                value="off"
            props.Set('org.bluez.MediaPlayer1', "Shuffle", value)
        
        
    def browser(self):
        device=phone.getConnectedDevice()
        if device:
            try:
                bus = dbus.SystemBus()
                props = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_") + '/' + self.a2dpPlayer), 'org.bluez.MediaFolder1')
                path="/org/bluez/hci0/dev_" + device.replace(":","_") + "/" + self.a2dpPlayer + self.settings["a2dpPath"]
                print(path)
                props.ChangeFolder(path)
                items=json.loads(json.dumps(props.ListItems(''), indent=2))
                self.musicList.clear()
                self.musicList.clearSelection()
                if len(self.settings["a2dpPath"].split("/"))>2:
                    itm = QtGui.QListWidgetItem("Zurück");
                    itm.setIcon(QIcon("./images/folder_up.png"));
                    itm.setWhatsThis("-")
                    self.musicList.addItem(itm);
                
                for key in sorted(items.keys()):
                    parts=os.path.split(os.path.abspath(items[key]["Name"]))
                    itm = QtGui.QListWidgetItem(parts[1]);
                    im="./images/folder.png"
                    if items[key]["Playable"]==True: im="./images/song.png"
                    itm.setIcon(QIcon(im));
                    itm.setWhatsThis(key)
                    itm.setStatusTip(str(items[key]["Playable"]))
                    self.musicList.addItem(itm);
            except:
                #phone.disconnect(device)
                pass
            
    def select(self):
        device=phone.getConnectedDevice()
        playable=self.musicList.currentItem().statusTip()
        path=self.musicList.currentItem().whatsThis()
        print(playable, path)
        if path=="-":
            ca=self.lbl_currentAlbum.text().rsplit('/', 1)
            self.lbl_currentAlbum.setText(ca[0])
        else:
            if playable=="0":
                self.lbl_currentAlbum.setText(self.lbl_currentAlbum.text()+"/"+self.musicList.currentItem().text())
        bus = dbus.SystemBus()
        if playable=="1":
            player = dbus.Interface(bus.get_object('org.bluez', path), 'org.bluez.MediaItem1')
            player.Play()
        else:
            if path=="-":
                path=self.settings["a2dpPath"]
                parts=path.rsplit('/', 1)
                newPath=parts[0]
            else:
                newPath=path.replace("/org/bluez/hci0/dev_" + device.replace(":","_") + "/" + self.a2dpPlayer, "")
            self.settings["a2dpPath"]=newPath
            self.browser()

    def setPlayer(self):
        device=phone.getConnectedDevice()
        if (device):
            bus = dbus.SystemBus()
            introspect = dbus.Interface(bus.get_object('org.bluez', '/org/bluez/hci0/dev_' + device.replace(":","_")), 'org.freedesktop.DBus.Introspectable')
            dom = minidom.parseString(introspect.Introspect())
            root = dom.documentElement
            for node in root.childNodes:
                if 'player' in node.attributes['name'].value:
                    self.a2dpPlayer=node.attributes['name'].value
        
########################################################################
##
## Slide functions
##
########################################################################

    def startSlide(self, direction):
        if direction=="left":
            self.slideEnd=self.frame.x()-700
        else:
            self.slideEnd=self.frame.x()+700       
        self.slideTimer = QtCore.QTimer()
        self.slideTimer.timeout.connect(lambda: self.slideFrame(direction))
        self.slideTimer.start(10)
               
    def slideFrame(self, direction):
        if direction=="left":
            x=self.frame.x()-25
        else:
            x=self.frame.x()+25
        self.frame.setGeometry(QtCore.QRect(x, 0, 1400, 480))
        if x==self.slideEnd:
            self.slideTimer.stop()
        
        
        
        
def main():
    app = QtGui.QApplication(sys.argv)
    form = pya2dp()
    form.show()
    sys.exit(app.exec_())
    
if __name__ == "__main__":
    main()