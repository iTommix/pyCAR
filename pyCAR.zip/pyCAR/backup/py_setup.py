from PyQt4 import QtCore, QtGui, uic
from PyQt4.QtGui import QIcon
#from pulsectl import Pulse
import pulsectl
import sys, os, json, time

path=os.path.dirname(os.path.abspath( __file__ )).rsplit('/', 1)
form_class = uic.loadUiType(path[0]+"/backup/sources/pysetup.ui")[0]





class setup(QtGui.QMainWindow, form_class):

    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self)
        self.pa = pulsectl.Pulse('pyCAR')
        
        for number in range(1,3):
            button = getattr(self, "deck"+str(number))
            button.clicked.connect(lambda: self.setDeck())
        self.getPulse()
        self.setSoundcards()
        self.setProfiles()


        


    def getPulse(self):
        self.pulse={}
        # get Cards
        for c in self.pa.card_list():
            card=c.proplist
            cardprofile={}
            z=0
            for profile in c.profile_list:
                cardprofile[z]={}
                splitted=str(profile).split(",")
                for item in splitted:
                    key,value=item.replace(" ","").split("=")
                    cardprofile[z][key]=value.replace("'","")
                z+=1
            card["profiles"]=cardprofile
            card["currentProfileName"]=cardprofile[z-1]["name"]
            card["currentProfileID"]=z-1
            self.pulse[int(card["alsa.card"])]=card
        print(json.dumps(self.pulse, indent=4, sort_keys=True))
        
        
        """
        with Pulse('volume-increaser') as pulse:
            for card in pulse.card_list():
                card=card.proplist
                #itm = QtGui.QComboWidgetItem();
                self.soundcards.addItem(card["alsa.card_name"]);
        """       

    def setSoundcards(self):
        for card in self.pulse:
            self.soundcards.addItem(self.pulse[card]["alsa.card_name"])
        self.soundcards.currentIndexChanged.connect(self.setProfiles)
            
    def setProfiles(self):
        for profiles in self.pulse[self.soundcards.currentIndex()]["profiles"]:
            self.cardprofiles.addItem(self.pulse[self.soundcards.currentIndex()]["profiles"][profiles]["description"])

        


    def setDeck(self):
        button=self.sender()
        index=button.objectName().replace("deck","")
        self.sounddecks.setCurrentIndex(int(index)-1)



def main():
    app = QtGui.QApplication(sys.argv)
    form = setup()
    form.show()
    sys.exit(app.exec_())
    
if __name__ == "__main__":
    main()