from PyQt4 import QtCore, QtGui, uic
from PyQt4.QtGui import QIcon
import sys, os, json, time, dbus, sqlite3
import modules.phone as phone, modules.functions as functions



path=os.path.dirname(os.path.abspath( __file__ )).rsplit('/', 1)
form_class = uic.loadUiType(path[0]+"/sources/pyphone.ui")[0]

settings = {
}


class pyphone(QtGui.QMainWindow, form_class):

    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.parent=parent
        self.settings=settings
        self.setupUi(self)
        
        self.call=0
        self.callPath=None
        self.path=None
        self.phoneBookLoaded=False
        
        self.phonebookList.verticalScrollBar().setStyleSheet("QScrollBar:vertical {width:50px}");
        self.tblPhoneNumbers.verticalScrollBar().setStyleSheet("QScrollBar:vertical {width:50px}");
        
        
        self.btnPhone1.clicked.connect(lambda: self.phoneButton('1'))
        self.btnPhone2.clicked.connect(lambda: self.phoneButton('2'))
        self.btnPhone3.clicked.connect(lambda: self.phoneButton('3'))
        self.btnPhone4.clicked.connect(lambda: self.phoneButton('4'))
        self.btnPhone5.clicked.connect(lambda: self.phoneButton('5'))
        self.btnPhone6.clicked.connect(lambda: self.phoneButton('6'))
        self.btnPhone7.clicked.connect(lambda: self.phoneButton('7'))
        self.btnPhone8.clicked.connect(lambda: self.phoneButton('8'))
        self.btnPhone9.clicked.connect(lambda: self.phoneButton('9'))
        self.btnPhone0.clicked.connect(lambda: self.phoneButton('0'))
        self.btnPhone10.clicked.connect(lambda: self.phoneButton('*'))
        self.btnPhone11.clicked.connect(lambda: self.phoneButton('#'))
        self.btnDelete.clicked.connect(lambda: self.phoneDelete())
        self.btnCallNumber.clicked.connect(lambda: self.makePhoneCall())
        self.btnCallNumber.setIcon(QIcon(path[0]+"/images/call.png"));
        self.btnCallNumber.setIconSize(QtCore.QSize(100,100))
        
        self.btnPhonebook.setIcon(QIcon(path[0]+"/images/phonebook.png"));
        self.btnPhonebook.setIconSize(QtCore.QSize(100,100))
        
        self.phonebookList.itemClicked.connect(self.PhoneNumbers)
        self.tblPhoneNumbers.itemClicked.connect(self.phoneNumberSelected)
        self.btnPhonebook.clicked.connect(lambda: self.startSlide("left"))
        self.btnBackPhone.clicked.connect(lambda: self.startSlide("right"))
        self.slideback2.clicked.connect(lambda: self.startSlide("right"))
        
        self.btnCallAnswer.clicked.connect(lambda: self.answerRejectCall('answer'))
        self.btnCallReject.clicked.connect(lambda: self.answerRejectCall('reject'))
        
        self.detectCall = QtCore.QTimer()
        self.detectCall.timeout.connect(self.detectIncomingCall)
        self.detectCall.start(1000)
        self.Phonebook()
    
    
    
    
    def phoneButton(self, value):
        self.lblPhoneNumber.setText(self.lblPhoneNumber.text() + value)
        
    def phoneDelete(self):
        number=self.lblPhoneNumber.text()
        self.lblPhoneNumber.setText(number[:-1])
        
    def makePhoneCall(self):
        bus = dbus.SystemBus()
        if self.call==0:
            self.parent.muteAll("phone")
            print("Call to " + self.lblPhoneNumber.text())
            manager = dbus.Interface(bus.get_object('org.ofono', '/'),
                                                            'org.ofono.Manager')
            modems = manager.GetModems()
            modem = modems[0][0]      
            hide_callerid = "default"
            number = self.lblPhoneNumber.text()
            print("Using modem %s" % modem)
            vcm = dbus.Interface(bus.get_object('org.ofono', modem),
                                                            'org.ofono.VoiceCallManager')
            self.callPath = vcm.Dial(number, hide_callerid)
            self.btnCallNumber.setIcon(QIcon(path[0]+"/images/callend.png"));
            #self.btnCallNumber.setStyleSheet("background-image: url(./images/callend.png);background-repeat: none;border: 0px;")
            self.call=1
        else:
            caller = dbus.Interface(bus.get_object('org.ofono', self.callPath),
                                                        'org.ofono.VoiceCall')
            caller.Hangup()
            self.endCall()
            
    def endCall(self):
        self.call=0
        self.btnCallNumber.setIcon(QIcon(path[0]+"/images/call.png"));
        #self.btnCallNumber.setStyleSheet("background-image: url(./images/call.png);background-repeat: none;border: 0px;")
        self.lblPhoneNumber.setText("")
        self.parent.play()
        
    def answerRejectCall(self, mode):
        #path = self.getPath()
        bus = dbus.SystemBus()
        call = dbus.Interface(bus.get_object('org.ofono', self.path),'org.ofono.VoiceCall')
        if mode=='answer':
            call.Answer()
        else:
            call.Hangup()
    
    def detectIncomingCall(self):
        if phone.getConnectedDevice()==False:
            return
        if self.phoneBookLoaded==False: self.Phonebook()
        bus = dbus.SystemBus()
        manager = dbus.Interface(bus.get_object('org.ofono', '/'),'org.ofono.Manager')
        modems = manager.GetModems()
        for path, properties in modems:
                #print("[ %s ]" % (path))
                mac = path.replace("/hfp/org/bluez/hci0/dev_","").replace("_", ":")
                if "org.ofono.VoiceCallManager" not in properties["Interfaces"]:
                        continue
                mgr = dbus.Interface(bus.get_object('org.ofono', path),'org.ofono.VoiceCallManager')
                calls = mgr.GetCalls()
                callState=""
                for path, properties in calls:
                    self.path=path
                    callState = properties["State"]
                    #print("[ %s ] %s" % (path, callState))
                    #print(callState)
                    if callState=='active':
                        self.call=1
                        functions.setMicActive(True)
                    if callState=='incoming':
                        if self.call==0: self.parent.muteAll("phone");
                        self.call=1
                        if self.parent.mainFrame.currentIndex() != 3:
                            if properties["LineIdentification"] != "":
                                number = self.getCaller(properties["LineIdentification"])
                            else:
                                number = "Anonym"
                            self.lblPhoneIncomingNumber.setText(number)
                            self.parent.mainFrame.setCurrentIndex(3)
                            self.frame.setGeometry(QtCore.QRect(-2100, 0, 2800, 480))
       
                if callState=="" and self.call==1:
                    self.frame.setGeometry(QtCore.QRect(0, 0, 2100, 480))
                    self.endCall()

    def Phonebook(self):
        self.phonebookList.clear()
        if phone.getConnectedDevice():
            device=phone.getConnectedDevice()
            if(device):
                database="/media/pi/pyCar/Phone/Phonebooks/" + device.replace(":", "_") + ".db"
                conn = sqlite3.connect(database)
                cursor = conn.cursor()
                for row in cursor.execute("SELECT uid, surname, first_name  FROM names ORDER BY surname, first_name"):
                    if row[1]!="":
                        name=row[1]+", "+row[2]
                    else:
                        name=row[2]
                    itm = QtGui.QListWidgetItem(name);
                    itm.setWhatsThis(row[0])
                    self.phonebookList.addItem(itm)
                self.phoneBookLoaded=True
                
    def getPhonebook():
        phone.getPhonebook()
        self.Phonebook()
    
    def PhoneNumbers(self):  
        self.tblPhoneNumbers.clear()
        self.tblPhoneNumbers.setColumnWidth(0,180)
        self.tblPhoneNumbers.setColumnWidth(1,400)
        uid=self.phonebookList.currentItem().whatsThis()
        print(uid)
        device=phone.getConnectedDevice()
        print(device)
        database="/media/pi/pyCar/Phone/Phonebooks/" + device.replace(":", "_") + ".db"
        conn = sqlite3.connect(database)
        cursor = conn.cursor()
        c=0
        cursor.execute("SELECT count(*) FROM numbers WHERE uid='"+uid+"' AND number LIKE '+%'")
        rows = cursor.fetchone()
        self.tblPhoneNumbers.setRowCount(rows[0])
        for row in cursor.execute("SELECT type, number FROM numbers WHERE uid='"+uid+"' AND number LIKE '+%' ORDER BY type"):
            newitem = QtGui.QTableWidgetItem(row[0])
            self.tblPhoneNumbers.setItem(c,0,newitem)
            newitem = QtGui.QTableWidgetItem(row[1])
            self.tblPhoneNumbers.setItem(c,1,newitem)
            c+=1
        #self.tblPhoneNumbers.resizeColumnsToContents()
        self.lblPhoneName.setText(self.phonebookList.currentItem().text())      
        self.startSlide("left")

        
        
    def getCaller(self, number):
        device=phone.getConnectedDevice()
        database="/media/pi/pyCar/Phone/Phonebooks/" + device.replace(":", "_") + ".db"
        conn = sqlite3.connect(database)
        cursor = conn.cursor()
        cursor.execute("SELECT nu.uid, na.first_name, na.surname FROM numbers nu LEFT JOIN names na ON na.uid=nu.uid WHERE nu.number='"+ number +"'")
        row=cursor.fetchone()
        try:
            return row[1]+" "+row[2]
        except:
            return number
        
    def phoneNumberSelected(self):
        number = self.tblPhoneNumbers.item(self.tblPhoneNumbers.currentRow(),1).text()
        self.lblPhoneNumber.setText("+"+str(self.getNumber(number)))
        self.frame.setGeometry(QtCore.QRect(0, 0, 2100, 480))
        self.makePhoneCall()
        
    def getNumber(self, number):
        return int(''.join(ele for ele in number if ele.isdigit()))
    
    def getPath(self):
        device=phone.getConnectedDevice()
        return "/hfp/org/bluez/hci0/dev_"+device.replace(":","_")
    
    
########################################################################
##
## Slide functions
##
########################################################################

    def startSlide(self, direction):
        if direction=="left":
            self.slideEnd=self.frame.x()-700
        else:
            self.slideEnd=self.frame.x()+700       
        self.slideTimer = QtCore.QTimer()
        self.slideTimer.timeout.connect(lambda: self.slideFrame(direction))
        self.slideTimer.start(10)
               
    def slideFrame(self, direction):
        if direction=="left":
            x=self.frame.x()-25
        else:
            x=self.frame.x()+25
        self.frame.setGeometry(QtCore.QRect(x, 0, 2100, 480))
        if x==self.slideEnd:
            self.slideTimer.stop()
        
        
        
        
def main():
    app = QtGui.QApplication(sys.argv)
    form = pyphone()
    form.show()
    sys.exit(app.exec_())
    
if __name__ == "__main__":
    main()