#!/bin/bash
clear
echo "***************************************"
echo "** Install needed Packages           **"
echo "***************************************"
sudo apt-get --yes --force-yes install subversion imagemagick libdbus-1-dev libdbus-glib-1-dev libfontconfig1-dev libfreetype6-dev libfribidi-dev libimlib2-dev librsvg2-bin libspeechd-dev libxml2-dev ttf-liberation libgtk2.0-dev
sudo apt-get --yes --force-yes install gcc g++ cmake make zlib1g-dev libpng12-dev librsvg2-bin
sudo apt-get --yes --force-yes install libsdl-image1.2-dev libdevil-dev libglc-dev freeglut3-dev libxmu-dev libfribidi-dev
sudo apt-get --yes --force-yes install libglc-dev freeglut3-dev libgl1-mesa-dev libfreeimage-dev libqt4-dev libgps-dev espeak 
sudo apt-get --yes --force-yes install bluez bluez-firmware gpsd gpsd-clients unclutter
sudo apt-get --yes --force-yes install checkinstall git libpulse-dev mplayer2
sudo apt-get --yes --force-yes install intltool libsndfile1 pavucontrol ofono
sudo apt-get --yes --force-yes install tightvncserver mc mplayer ntfs-3g
sudo apt-get --yes --force-yes build-dep pulseaudio
clear
echo "***************************************"
echo "** Build Pulseaudio from the scratch **"
echo "***************************************"
git clone git://anongit.freedesktop.org/pulseaudio/pulseaudio
cd pulseaudio/
NOCONFIGURE=1 ./bootstrap.sh
CFLAGS="-g -O2 -fstack-protector --param=ssp-buffer-size=4 -Wformat -Wformat-security -g -O2 -fstack-protector --param=ssp-buffer-size=4 -Wformat -Wformat-security -Werror=format-security -Wall" CXXFLAGS="-g -O2 -fstack-protector --param=ssp-buffer-size=4 -Wformat -Wformat-security -g -O2 -fstack-protector --param=ssp-buffer-size=4 -Wformat -Wformat-security -Werror=format-security -Wall" CPPFLAGS="-D_FORTIFY_SOURCE=2" LDFLAGS="-Wl,-Bsymbolic-functions -Wl,-z,relro -Wl,--no-as-needed -lxcb" $HOME/install/pulseaudio/./configure --prefix=/usr/local --includedir="\${prefix}/include" --mandir="\${prefix}/share/man" --infodir="\${prefix}/share/info" --sysconfdir=/etc --localstatedir=/var --libexecdir="\${prefix}/lib/pulseaudio" --srcdir=. --disable-maintainer-mode --disable-dependency-tracking --disable-silent-rules --disable-hal --libdir=\${prefix}/lib/x86_64-linux-gnu --with-module-dir=\${prefix}/lib/pulse/modules --disable-oss-wrapper --without-caps
make -j$(nproc)
sudo make install
sudo usermod -a -G pulse-access pi
cd ..
clear
echo "***************************************"
echo "** Build navit from the scratch      **"
echo "***************************************"
svn co svn://svn.code.sf.net/p/navit/code/trunk/navit/ navit-source
mkdir navit-build
cd navit-build
cmake --enable-map-csv ~/install/navit-source -DFREETYPE_INCLUDE_DIRS=/usr/include/freetype2/
make -j$(nproc)
sudo cp navit/navit /usr/bin/
sudo chmod +x /usr/bin/navit
sudo mkdir /usr/local/share/navit
cd navit
sudo find . -name "*.so" -type f -exec cp {} /usr/local/share/navit/ \;
cd /home/pi/install/
unzip nav.zip
sudo cp -R nav/buttons /usr/local/share/navit/
sudo cp nav/navit.xml /usr/local/share/navit/
clear
echo "***************************************"
echo "** Copy some files                   **"
echo "***************************************"
unzip etc.zip
#sudo ln -s /usr/share/X11/xorg.conf.d /etc/X11/
#sudo cp etc/X11/xorg.conf.d/30-touch.conf /etc/X11/xorg.conf.d/
sudo cp etc/bluetooth/main.conf /etc/bluetooth/
sudo cp etc/pulse/* /etc/pulse/
sudo cp etc/systemd/system/pulseaudio.service /etc/systemd/system/
sudo cp etc/dbus-1/system.d/ofono.conf /etc/dbus-1/system.d/
sudo cp etc/xdg/autostart/pyCar.desktop /etc/xdg/autostart/
sudo cp splash.png /usr/share/plymouth/themes/pix/
sudo systemctl --system enable pulseaudio.service
sudo systemctl --system start pulseaudio.service
echo -e 'discoverable on' | bluetoothctl
clear
echo "***************************************"
echo "** install needed python3 modules    **"
echo "***************************************"
# gpsd-py3==0.2.0', 'mplayer.py==0.7.0', 'netifaces==0.10.5', 'nobex==1.0.0', 'pillow==3.3.1', 'psutil==5.0.1', 'pyalsaaudio==0.8.2', 'pybluez==0.22', 'python-dateutil==2.5.3', 'vobject==0.9.3
sudo apt-get --yes --force-yes install python3-dbus python3-mutagen python3-pyqt4 pyqt4-dev-tools
sudo pip3 install pyalsaaudio
sudo pip3 install netifaces
sudo pip3 install psutil
sudo pip3 install pybluez
# manually install mplayer and nOBEX
unzip mplayer.zip
cd mplayer
sudo python3 setup.py install
cd ..
unzip nOBEX.zip
cd nOBEX
sudo python3 setup.py install
cd ..
clear
echo "***************************************"
echo "** Install pyCAR                     **"
echo "***************************************"
sudo mkdir /home/pyCAR
sudo chown pi:pi /home/pyCAR
unzip pyCAR.zip -d /home/pyCAR/
clear
echo "***************************************"
echo "** clean up                          **"
echo "***************************************"
sudo apt-get --yes --force-yes autoremove
cd /home/pi
sudo rm -R install/
clear
echo "********************************************************************"
echo "** Finished. We reboot the system and start pyCAR. Ready? [ENTER] **"
echo "********************************************************************"
read ok
sudo reboot



