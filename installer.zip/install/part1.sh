#!/bin/bash
clear
echo "***************************************"
echo "** Remove not needed Packages        **"
echo "***************************************"
sudo apt-get --yes --force-yes remove --purge minecraft-pi 
sudo apt-get --yes --force-yes remove --purge scratch
sudo apt-get --yes --force-yes remove --purge wolfram-engine
sudo apt-get --yes --force-yes remove --purge debian-reference-*
sudo apt-get --yes --force-yes remove --purge epiphany-browser*
sudo apt-get --yes --force-yes remove --purge sonic-pi 
sudo apt-get --yes --force-yes remove --purge supercollider*
sudo apt-get --yes --force-yes remove --purge chromium-browser
sudo apt-get --yes --force-yes remove --purge pulseaudio*
sudo apt-get --yes --force-yes remove --purge libreoffice*
sudo apt-get --yes --force-yes remove --purge claws-mail*
sudo apt-get --yes --force-yes remove --purge realvnc*
sudo apt-get --yes --force-yes clean
rm -r /home/pi/python_games/
sudo apt-get --yes --force-yes autoremove
clear
echo "***************************************"
echo "** Update apt and upgrade System     **"
echo "***************************************"
sudo sh -c "echo 'deb-src http://archive.raspbian.org/raspbian/ jessie main contrib non-free rpi' >> /etc/apt/sources.list"
sudo apt-get update
sudo apt-get --yes --force-yes upgrade
clear
echo "***************************************"
echo "** Some Modifications on config.txt  **"
echo "***************************************"
sudo sh -c "echo 'lcd_rotate=2' >> /boot/config.txt"
sudo sh -c "echo 'dtoverlay=pi3-disable-bt' >> /boot/config.txt"
sudo sh -c "echo 'avoid_warnings=1' >> /boot/config.txt"
sudo sh -c "echo 'blacklist snd_bcm2835' >> /etc/modprobe.d/raspi-blacklist.conf"
clear
echo "***************************************"
echo "** disable screensaver               **"
echo "***************************************"
sudo sh -c "echo '@xset s noblank' >> /etc/xdg/lxsession/LXDE-pi/autostart"
sudo sh -c "echo '@xset s off' >> /etc/xdg/lxsession/LXDE-pi/autostart"
sudo sh -c "echo '@xset -dpms' >> /etc/xdg/lxsession/LXDE-pi/autostart"
sudo sed -i 's/#xserver-command=X/xserver-command=X -s 0 dpms/g' /etc/lightdm/lightdm.conf
sudo sed -i 's/raspberrypi/pyCAR/g' /etc/hostname
mv part1.sh part1.bak
clear
echo "We should now reboot the System. After Reboot start the installscript again. [ENTER]:"
read ok
sudo reboot
