#!/bin/bash
if [ -f "./part1.sh" ]; then
   ./part1.sh
elif [ -f "./part2.sh" ]; then
   ./part2.sh
fi